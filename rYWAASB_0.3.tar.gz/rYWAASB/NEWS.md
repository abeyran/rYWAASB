# rYWAASB 0.3
## Changes:
* scree plot added.


# rYWAASB 0.2
## Changes:
* Hierarchical cluster categorization of observations added along with determining the cluster number by `Average Silhouette Method` algorithm enforced with bootstrap and jakknife iterations. 

* An important biplot created clustering the genotypes based on rYWAASB, WAASB and WAASBY with loadings.

* [Lifecycle badges](https://lifecycle.r-lib.org/articles/stages.html) added to the functions' documentation.
* The bug in representation of Description file contents, removed.

# rYWAASB 0.1
* The initial edition of this software was established in 2024.

